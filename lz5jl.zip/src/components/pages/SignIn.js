import React from "react";
import "../../App.css";

export default function SignIn() {
  return <h1 className="sign-in">HELLO IT'S MEE!</h1>;
}
